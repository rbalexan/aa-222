## top-level submission file


"""
    f(a, b) = c
A function that adds the inputs `a` and `b`
"""
function f(a, b)
    return a + b
end
